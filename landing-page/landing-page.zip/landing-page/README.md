# Landing Page Project

## Table of Contents


In this project I converted a static document into a dynamic, interactive one. The document includes a simple landing page who's navigation bar builds dynamically according to the number of items to be displayed. The page scrolls to the appropriate section when a navigation link is clicked and each section is highlighted when it becomes the current active content. 